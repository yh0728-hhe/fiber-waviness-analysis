# Fiber waviness: quick review

This is an exploratory image-analysis prototype. Automatic QC has not been validated against expert fiber traces, and the results do not establish a CD-versus-DMSO biological difference.

1. Read `docs/PROFESSOR_OVERVIEW.md`.
2. Open `report/review.html` in Safari or Chrome. It works offline and embeds seven representative slices, showing automatic-QC and needs-review candidate paths.
3. Inspect `results/overview.png` and `results/representative_overlays.jpg`.
4. Read `docs/VALIDATION.md` before interpreting the tables.

Waviness is the smoothed centerline length divided by endpoint distance. The saved measurements describe candidate 2D segments, not independently validated complete fibers or specimen-level treatment effects.

This smaller package contains selected tables, figures, and an offline viewer. Source code, all 68 derived-image sets, complete compressed candidate data, and validation records are available in the [public repository](https://github.com/yh0728-hhe/fiber-waviness-analysis). Links to files omitted from this package open that repository.

Download everything using GitHub's **Code → Download ZIP**. Original microscopy TIFF/CZI files, correspondence, and the thesis are not included.
